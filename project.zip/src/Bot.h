#ifndef BOT_H
#define BOT_H

class Bot {
    public:
        Bot(int a, int b);

        void doStuff(int a, int b);

    private:
        int a_;
        int b_;
};

#endif
