Minesweeper bot for Drexel CS283 Summer 2013

Will play gnomine, tested on ubuntu
